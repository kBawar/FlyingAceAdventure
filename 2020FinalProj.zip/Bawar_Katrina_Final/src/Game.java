/**
 * 
 * the physical game
 *
 */

import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;

import javax.swing.*;
import java.awt.*;

public class Game extends JPanel implements ActionListener
{
	private int level;
	private Player pCopy;
	private Ellipse2D[] obstacles; // obstacles
	
	private int xUser = 0; // user
	Timer t = new Timer(5, this); // every 5 milliseconds
	private long startTime = 0, curTime = 0, timeLost = 0, saveTime = 0;
	
	JLabel timeLimit = new JLabel(""+2000);
	
	int y = 0, y2 = 600, velY = 2, velY2 = -3; // obstacles
	
	public Game(Player player)
	{
		setLayout(null);
		setBounds(0, 0, 1000, 680); // used to help later
		
		pCopy = player; // makes aliases
		level = pCopy.getLevel();
		obstacles = new Ellipse2D[pCopy.getLevel()+1]; // proper set up, avoid impossibilitU* **

		pCopy.setPlay(true);
		pCopy.setLost(false);
		
		JButton pause = new JButton(new ImageIcon("pauseBlue.png"));
		pause.setBounds(15, 15, 35, 35);
		pause.setBackground(new Color(255, 255, 255));
		
		Font time = new Font(Font.DIALOG, Font.BOLD, 30);
		timeLimit.setBounds(60, 15, 100, 30);
		timeLimit.setFont(time);
		
		JLabel levelDisplay = new JLabel("LEVEL " + pCopy.getLevel());
		levelDisplay.setBounds(850, 15, 200, 40);
		levelDisplay.setFont(time);
		
		setBackground(new Color(184, 219, 245));		
		
		Action leftAction = new AbstractAction() // <-
		{
			@Override
			public void actionPerformed(ActionEvent left)
			{
				if (pCopy.isPlaying()) // only works if user is playing
				{
					xUser -= 8;
					if (xUser < 0)
						xUser = 0;
					repaint();
				}
			}
		};
		Action rightAction = new AbstractAction() // ->
		{
			@Override
			public void actionPerformed(ActionEvent right)
			{
				if (pCopy.isPlaying()) // only if user is playing
				{
					xUser += 8;
					if (xUser + 50 > getWidth())
						xUser = getWidth() - 50;
					repaint();
				}
			}
		};

		bindKeyStroke(WHEN_IN_FOCUSED_WINDOW, "move.left", KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), leftAction);
		bindKeyStroke(WHEN_IN_FOCUSED_WINDOW, "move.right", KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), rightAction);
		
		JPanel pauseP = new JPanel();
		pauseP.setBounds(80, 80, 825, 475);
		pauseP.setBackground(new Color(255, 255, 255, 50)); // last param is opacity
		pauseP.setLayout(null);
		
		JLabel pText = new JLabel("PAUSED");
		pText.setBounds(250, 160, 400, 100); // 185
		Font f = new Font(Font.DIALOG, Font.BOLD, 75);
		pText.setFont(f);
		
		JButton mainMenu = new JButton("MAIN MENU");
		mainMenu.setBounds(325, 260, 150, 30);
		mainMenu.setBackground(new Color(255, 255, 255));
		JButton quit = new JButton("QUIT");
		quit.setBounds(325, 300, 150, 30);
		quit.setBackground(new Color(255, 255, 255));
		
		mainMenu.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent back)
			{
				Main.mainMenu();
				setVisible(false);
				pCopy.setPlay(false);
			}
		});
		
		quit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent exit)
			{
				System.exit(0);
			}
		});
		
		pauseP.add(quit);
		pauseP.add(mainMenu);
		pauseP.add(pText);
	
		pause.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent pausing)
			{
				add(pauseP);
	
				if (pCopy.isPlaying()) // pause
				{
					t.stop(); // all movement stops
					saveTime = System.currentTimeMillis();
					
					pause.setIcon(new ImageIcon("playBlue.png"));
					pauseP.setVisible(true);
				}
				else // unpause
				{
					timeLost = timeLost + (System.currentTimeMillis()-saveTime);
					t.start();

					pause.setIcon(new ImageIcon("pauseBlue.png"));
					pauseP.setVisible(false);
				}
				
				pCopy.setPlay(!pCopy.isPlaying()); // on/off
				repaint();
			}
		});
		
		add(pause);
		add(timeLimit);
		add(levelDisplay);
		
		t.restart();
		t.start();
		startTime = System.currentTimeMillis();
	}
	
	protected void bindKeyStroke(int condition, String name, KeyStroke keyS, Action ac)
	{
		InputMap im = getInputMap(condition);
		ActionMap am = getActionMap();
		
		im.put(keyS, name);
		am.put(name, ac);
	}
	
	@Override
	public Dimension getPreferredSize() // bounds?
	{
		return new Dimension(1000, 680);
	}
	
	/**
	 *  Deals with Displaying the Newly Incremented Objects
	 */
	protected void paintComponent(Graphics g)
	{
		// obstacles
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D) g;
		g2.setPaint(new Color(45, 85, 125));
		for(int i = 0; i < obstacles.length; i++)
		{
			if ((i+1)%2 != 0) // odd
			{
				if (i == 4) // 5th obstacle
					obstacles[i] = new Ellipse2D.Double(450, y, 20, 20);
				else
					obstacles[i] = new Ellipse2D.Double(200 + (i * 25), y, 20, 20);
			}
			else // even
			{
				if (i == 5) // 6th obstacle
					obstacles[i] = new Ellipse2D.Double(850, y2, 20, 20);
				else	
					obstacles[i] = new Ellipse2D.Double(600 + (i * 25), y2, 20, 20);
			}
			g2.fill(obstacles[i]);
		}
		
		// user
		ImageIcon user = new ImageIcon("snoopyUser.png");
		g2.drawImage(user.getImage(), xUser, getHeight()/2-50, this); // 200x120 (200, 133)
	}
	
	/**
	 *  Checks Collisions and Increments Position of Objects
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (y < 0 || y > getHeight()-20) // keeps obstacle in bounds
			velY = -velY;
		if (y2 < 0 || y2 > getHeight()-20)
			velY2 = -velY2;
		
		boolean collided = false;

		for(int i = 0; i < obstacles.length&&collided==false; i++) // collision check
		{
			if (hasCollided(i)) // crash
			{		
				t.stop(); // all movement stops
				
				pCopy.setLevel(level); // modifies player's level
				pCopy.setPlay(false); // game over
				pCopy.setLost(true); // player loses
				
				Main.finishing(pCopy); // goes to finish panel
				
				setVisible(false);
				collided = true;
			}
		}

		if ((xUser > getWidth() - 100)&&(pCopy.getLost()==false)) // completed level & didn't crash
		{
			t.stop(); // all movement stops
			 
			pCopy.setLevel(level); // modifies player's level
			pCopy.setScore(curTime);
			pCopy.setPlay(false); 
			
			if (pCopy.getLevel() == 5) // 5 levels max
				Main.finishing(pCopy);
			else
				Main.keepPlaying(pCopy); 
			
			setVisible(false); // stops keybinding
		}

		if (t.isRunning()&&pCopy.isPlaying()) // only update while timer is running/player still playing
		{
			y += velY;
			y2 += velY2;
			repaint(); // updates
		}
		
		curTime = 2000-((System.currentTimeMillis()-startTime)-timeLost)/1000;
		timeLimit.setText(""+curTime); // time left (seconds)
	}
	
	/**
	 *  Detects Collision, called in actionPerformed. Finds the distance between the center
	 *  points of the obstacle and user to see if they collided.
	 */
	public boolean hasCollided(int i)
	{
		boolean collided = false;
		boolean xCollision = false;
		
		if ((i+1)%2 != 0) // odd
		{
			if ((i == 4)&&(Math.abs(460 - (xUser+46)) < 56)) // 5th obstacle
				xCollision = true;
			else if ((i != 4)&&(Math.abs((200+(i*25)+10) - (xUser+46)) < 56))
				xCollision = true;
		}
		else // even
		{
			if ((i == 5)&&(Math.abs(860 - (xUser+46)) < 56)) // 6th
				xCollision = true;
			else if ((i != 5)&&(Math.abs((600+(i*25)+10) - (xUser+46)) < 56)) 
				xCollision = true;
		}
		
		if ((obstacles[i].getY() > getHeight()/2-69 && obstacles[i].getY() < 404) && xCollision) 
			collided = true;
		
		return collided;
	}
}
