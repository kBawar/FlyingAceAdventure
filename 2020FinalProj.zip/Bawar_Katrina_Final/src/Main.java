import java.awt.event.*;

import javax.imageio.IIOParam;
import javax.swing.*;
import java.awt.*;

public class Main
{
	private static JFrame jf = new JFrame("Flying Ace Adventure!");
	
	public static void main(String[] args)
	{	
		mainMenu();
	}
	
	/**
	 *  Main Menu: restarts the current player
	 */
	public static void mainMenu () // no param, creates new player
	{
		JPanel mainP = new JPanel(); // main menu
		mainP.setBounds(0, 0, 1000, 680);
		mainP.setLayout(null);
		
		JLabel mainBack = new JLabel(new ImageIcon("mainSnoopy.png"));
		mainBack.setBounds(-10, -20, 1000, 680);
		
		JButton start = new JButton("START");
		start.setBounds(80, 300, 300, 60);
		start.setBackground(new Color(242, 107, 107));
		start.setForeground(Color.white);
		JButton instructions = new JButton("INSTRUCTIONS");
		instructions.setBounds(80, 400, 300, 60);
		instructions.setBackground(new Color(201, 77, 77));
		instructions.setForeground(Color.white);
		JButton quit = new JButton("QUIT");
		quit.setBounds(80, 500, 300, 60);
		quit.setBackground(new Color(150, 41, 41));
		quit.setForeground(Color.white);
		
		start.addActionListener(new ActionListener() // start
		{
			public void actionPerformed(ActionEvent start)
			{
				mainP.setVisible(false);
				
				Player p = new Player();
				Game gameP = new Game(p); // entirety of game
				jf.add(gameP);
			}
		});
		instructions.addActionListener(new ActionListener() // instructions
		{
			public void actionPerformed(ActionEvent instruct)
			{
				JPanel instructionsP = new JPanel();
				instructionsP.setBounds(0, 0, 1000, 680);
				instructionsP.setBackground(new Color(210, 171, 142));
				instructionsP.setLayout(null);
				
				JLabel gif = new JLabel(new ImageIcon("snooopy.gif"));
				gif.setBounds(10, 10, 500, 375);
				
				JPanel optionsP = new JPanel();
				optionsP.setBounds(10, 395, 500, 238);
				optionsP.setLayout(null);
			
				JButton back = new JButton("BACK");
				back.setBounds(192, 200, 100, 30);
				back.setBackground(new Color(255, 255, 255));
				JLabel story = new JLabel("<html>Welcome! You are helping Snoopy fly through the air, dodging attacks from the infamous"
						+ " Red Baron. Your objective? Make it to the end of the screen (right) as fast as you can without crashing!<html>");
				story.setBounds(20, -60, 455, 200);
				
				JButton info = new JButton("information");
				info.setBounds(40, 130, 125, 30);
				info.setBackground(new Color(220, 186, 173));
				info.setForeground(new Color(255, 255, 255));
				JButton controls = new JButton("controls");
				controls.setBounds(180, 130, 125, 30);
				controls.setBackground(new Color(220, 175, 146));
				controls.setForeground(new Color(255, 255, 255));
				JButton score = new JButton("score");
				score.setBounds(320, 130, 125, 30);
				score.setBackground(new Color(202, 160, 125));
				score.setForeground(new Color(255, 255, 255));
				
				back.addActionListener(new ActionListener() // back to main menu
				{
					public void actionPerformed(ActionEvent back)
					{
						instructionsP.setVisible(false);
						mainP.setVisible(true);
					}
				});
				
				JPanel infoP = new JPanel();
				JPanel controlsP = new JPanel();
				JPanel scoreP = new JPanel();
				
				info.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent information)
					{
						controlsP.setVisible(false);
						scoreP.setVisible(false);
						
						infoP.setBounds(520, 10, 455, 623);
						infoP.setBackground(new Color(220, 186, 173));
						infoP.setLayout(null);
						
						JLabel hitBox = new JLabel("<html>You are controlling Snoopy! When avoiding obstacles be "
								+ "aware of Snoopy's hitbox (white box). If an obstacle comes in contact within Snoopy's boundaries,"
								+ " you will crash! Snoopy moves left to right.<html>");
						hitBox.setBounds(20, 20, 440, 60);
						JPanel playerbox = new JPanel();
						playerbox.setBounds(180, 100, 93, 133);
						playerbox.setBackground(new Color(255, 255, 255, 75));
						JLabel user = new JLabel(new ImageIcon("snoopyUser.png"));
						user.setBounds(180, 100, 120, 200);
						
						JLabel obstacleText = new JLabel("<html>These are the obstacles that you are avoiding! Obstacles also have "
								+ "hitboxes (white box), which, if they come in contact with the user, will crash. Obstacles will "
								+ "be traveling up and down at different speeds.<html>");
						obstacleText.setBounds(20, 250, 440, 60);
						JPanel obstaclebox = new JPanel();
						obstaclebox.setBounds(215, 340, 31, 31);
						obstaclebox.setBackground(new Color(255, 255, 255, 75));
						JLabel obstacle = new JLabel(new ImageIcon("obstacle.png"));
						obstacle.setBounds(205, 330, 50, 50);
						
						JLabel warning = new JLabel("<html>TIP: Never go back to the main menu, unless you plan on restarting! "
								+ "Entering the main menu at any point will start you back at level 0...<html>");
						warning.setBounds(20, 400, 440, 60);
						
						JLabel status = new JLabel("<html>STATUS: As of right now, the highest level you can achieve is "
								+ "level 5. This is due to my lack of knowledge on game design! However, I hope to explore "
								+ "ways to prevent this and eventually get a 'never ending' game!<html>");
						status.setBounds(20, 500, 440, 60);
						
						infoP.add(warning);
						infoP.add(hitBox);
						infoP.add(user);
						infoP.add(playerbox);
						infoP.add(obstacleText);
						infoP.add(obstacle);
						infoP.add(obstaclebox);
						infoP.add(status);
						
						infoP.setVisible(true);
					}
				});
				controls.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent control)
					{				
						infoP.setVisible(false);
						scoreP.setVisible(false);
						
						controlsP.setBounds(520, 10, 455, 623);
						controlsP.setBackground(new Color(220, 175, 146));
						controlsP.setLayout(null);
						
						JLabel lAndR = new JLabel("<html>Use your left and right arrow keys to move Snoopy!<html>");
						lAndR.setBounds(80, 20, 440, 60);
						JLabel left = new JLabel(new ImageIcon("left.png"));
						left.setBounds(60, 40, 200, 200);
						JLabel right = new JLabel(new ImageIcon("right.png"));
						right.setBounds(190, 40, 200, 200);
						
						JLabel pauseInGame = new JLabel("<html>When in the game, a pause button appears in the top "
								+ "left corner. After clicking it, all objects will be immovable, including Snoopy. "
								+ "In order to resume playing, click the top left corner again. It will change icons "
								+ "from pause to resume after you click on it, so be sure to press that if that's what "
								+ "you want to do!");
						pauseInGame.setBounds(20, 250, 440, 80);
						JLabel pause = new JLabel(new ImageIcon("pauseBlue.png"));
						pause.setBounds(200, 350, 25, 25);
						JLabel resume = new JLabel(new ImageIcon("playBlue.png"));
						resume.setBounds(240, 350, 25, 25);
						
						JLabel visual = new JLabel(new ImageIcon("underAttack.gif"));
						visual.setBounds(60, 390, 337, 220);
						
						controlsP.add(lAndR);
						controlsP.add(left);
						controlsP.add(right);
						controlsP.add(pauseInGame);
						controlsP.add(pause);
						controlsP.add(resume);
						controlsP.add(visual);
						
						controlsP.setVisible(true);
					}
				});
				score.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent scores)
					{
						infoP.setVisible(false);
						controlsP.setVisible(false);

						scoreP.setBounds(520, 10, 455, 623);
						scoreP.setBackground(new Color(202, 160, 125));
						scoreP.setLayout(null);
						
						JLabel explain = new JLabel("<html>Your total score is calculated by adding all "
								+ "the scores from the levels you've completed. The score you receive from "
								+ "that level is displayed in the timer counting down in the top left "
								+ "corner, next to the pause button!<html>");
						explain.setBounds(20, 20, 440, 80);
						JLabel points = new JLabel("<html>The maximum amount of points you can get in a round "
								+ "is 2000! If you take longer than 2000 seconds, you will receive "
								+ "a score of 0 for that round...<html>");						
						points.setBounds(20, 375, 440, 80);
						
						JLabel visual = new JLabel(new ImageIcon("prepareSnoopy.gif"));
						visual.setBounds(70, 120, 325, 250);
						
						scoreP.add(explain);
						scoreP.add(points);
						scoreP.add(visual);
						
						scoreP.setVisible(true);
					}
				});
				
				instructionsP.add(infoP);
				instructionsP.add(controlsP);
				instructionsP.add(scoreP);
				
				optionsP.add(back);
				optionsP.add(story);
				optionsP.add(info);
				optionsP.add(controls);
				optionsP.add(score);
				
				instructionsP.add(optionsP);;
				instructionsP.add(gif);
				jf.add(instructionsP);

				mainP.setVisible(false);
			}
		});
		quit.addActionListener(new ActionListener() // quit
		{
			public void actionPerformed(ActionEvent exit)
			{
				System.exit(0); // exits frame
			}
		});

		mainP.add(start);
		mainP.add(instructions);
		mainP.add(quit);
		mainP.add(mainBack);

		// do not setLayout for jf
		jf.add(mainP);
		jf.setVisible(true);
		jf.setSize(1000, 680); // w h
		jf.setBackground(new Color(255, 255, 255));
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 *  Continue Screen: after player wins, asks if they want to continue, quit, or return to main menu
	 */
	public static void keepPlaying(Player p)
	{
		JPanel continueP = new JPanel();
		continueP.setBounds(0, 0, 1000, 680);
		continueP.setBackground(new Color(243,172,192));
		continueP.setLayout(null);
		
		JLabel congrats = new JLabel("CONGRATULATIONS YOU COMPLETED");
		congrats.setBounds(375, 30, 300, 30);
		
		Font f = new Font(Font.DIALOG, Font.BOLD, 80);
		JLabel lev = new JLabel("LEVEL " + p.getLevel());
		lev.setBounds(335, 45, 400, 100);
		lev.setFont(f);
		
		JPanel holdP = new JPanel();
		holdP.setBounds(500, 142, 388, 480);
		holdP.setBackground(new Color(242, 211, 223, 80));
		holdP.setLayout(null);
		
		Font pF = new Font(Font.DIALOG, Font.BOLD, 40);
		JLabel prompt = new JLabel("<html>PLAY THE<br/>NEXT LEVEL?<html>");
		
		JLabel prompt1 = new JLabel("PLAY THE");
		prompt1.setBounds(20, 50, 300, 50);
		prompt1.setFont(pF);
		JLabel prompt2 = new JLabel("NEXT LEVEL?");
		prompt2.setBounds(20, 90, 300, 50);
		prompt2.setFont(pF);
		
		prompt.setBounds(10, 0, 388, 480);
		prompt.setForeground(new Color(230, 134, 171));
		prompt.setFont(pF);
		
		Font responseF = new Font(Font.DIALOG, Font.ITALIC, 30);
		
		JButton yes = new JButton("YES");
		yes.setBounds(69, 170, 250, 80);
		yes.setForeground(new Color(230, 134, 171));
		yes.setBackground(new Color(242, 211, 223));
		yes.setFont(responseF);
		JButton no = new JButton("NO");
		no.setBounds(69, 270, 250, 80);
		no.setForeground(new Color(230, 134, 171));
		no.setBackground(new Color(242, 211, 223));
		no.setFont(responseF);
		
		JButton main = new JButton("MAIN MENU");
		main.setBounds(69, 370, 250, 30);
		main.setForeground(new Color(230, 134, 171));
		main.setBackground(new Color(242, 211, 223));
		
		JLabel warn = new JLabel("<html>Returning to the main menu will erase your progress!<html>");
		warn.setBounds(80, 400, 250, 30);
		Font warnF = new Font(Font.DIALOG, Font.PLAIN, 10);
		warn.setFont(warnF);
		
		JLabel snoopy = new JLabel(new ImageIcon("happySnoop.gif"));
		snoopy.setBounds(100, 140, 390, 485);

		yes.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent yes)
			{
				p.setLevel(p.getLevel()+1); // increment level
				
				Game gameP = new Game(p); // new game, different level
				
				jf.add(gameP);
				continueP.setVisible(false);
			}
		});
		
		no.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent no)
			{
				finishing(p);
				continueP.setVisible(false);
			}
		});	
		
		main.addActionListener(new ActionListener()
		{	
			public void actionPerformed(ActionEvent menu)
			{
				mainMenu();
				continueP.setVisible(false);
			}
		});
		
		holdP.add(prompt1);
		holdP.add(prompt2);
		
		holdP.add(yes);
		holdP.add(no);
		holdP.add(main);
		holdP.add(warn);

		continueP.add(holdP);
		
		continueP.add(congrats);
		continueP.add(lev);
		continueP.add(snoopy);
		
		jf.add(continueP);
	}
	
	/**
	 *  Finish Screen: after player loses/quits, enter initials and have score displayed
	 */
	public static void finishing(Player p)
	{
		JPanel finishP = new JPanel();
		finishP.setBounds(0, 0, 1000, 680);
		finishP.setBackground(new Color(250, 192, 112));
		finishP.setLayout(null);
		
		String backImage = "";
		
		if (p.getLost())
			backImage = "crash.gif";
		else // proceed to next round
			backImage = "lookingAtView.gif";
		
		JLabel back = new JLabel(new ImageIcon(backImage));
		back.setBounds(100, 40, 480, 320);
		
		JPanel initialsBack = new JPanel();
		initialsBack.setBounds(725, 150, 210, 75);
		initialsBack.setBackground(new Color(238, 148, 34));
		JLabel initials = new JLabel(""); // no bounds needed, layout built in
		Font f = new Font(Font.DIALOG, Font.BOLD, 50);
		initials.setFont(f);
		
		JPanel infoP = new JPanel(); // enter/info panel
		infoP.setBounds(690, 400, 293, 240);
		infoP.setLayout(null);
		infoP.setBackground(new Color(247, 181, 89));
		
		JPanel keyboardP = new JPanel(); // keyboard
		keyboardP.setBounds(0, 400, 690, 240);
		GridLayout gLayout = new GridLayout(3, 10);
		keyboardP.setLayout(gLayout);
		keyboardP.setBackground(new Color(255, 255, 255));
		
		JButton enter = new JButton("ENTER");
		enter.setBounds(100, 90, 100, 30);
		enter.setBackground(new Color(255, 255, 255));
		
		JLabel info = new JLabel("Enter initials to get your score!");
		info.setBounds(60, 0, 300, 300);
		
		JButton[] keys = new JButton[27];
		int alph = 0; // controls letters
		for (int count = 65; count < 92; count++)
		{
			if (alph == 26) // delete button
				keys[alph] = new JButton("DEL");
			else // alphabet keys
				keys[alph] = new JButton(Character.toString((char)count));
			
			if (alph < 9) 
				keys[alph].setBackground(new Color(238, 148, 34));
			else if (alph >= 9 && alph < 18) 
				keys[alph].setBackground(new Color(239, 126, 24));
			else // alph >= 18 
				keys[alph].setBackground(new Color(231, 108, 27));
			alph++;
		}	
		
		enter.addActionListener(new ActionListener() // displays score
		{
			public void actionPerformed (ActionEvent enter)
			{
				if (initials.getText().length() < 5)
					info.setText("Please input another character!");
				else
				{
					p.setName(initials.getText());
					finishP.setVisible(false);
					
					JPanel scoreP = new JPanel();
					scoreP.setBounds(0, 0, 1000, 680);
					scoreP.setBackground(new Color(183, 198, 205));
					scoreP.setLayout(null);
					
					JLabel visual = new JLabel(new ImageIcon("BABABA.gif"));
					visual.setBounds(270, 220, 450, 300);
					
					JLabel score = new JLabel(""+p.getScore());
					score.setBounds(360, 30, 300, 80);
					Font scoreF = new Font(Font.DIALOG, Font.BOLD, 100);
					score.setForeground(new Color(216, 49, 71));
					score.setFont(scoreF);

					Font ptsF = new Font(Font.DIALOG, Font.BOLD, 30);
					JLabel pts = new JLabel("pts");
					pts.setBounds(580, 80, 100, 30);
					pts.setForeground(new Color(0, 0, 0));
					pts.setFont(ptsF);
					
					Font infoF = new Font(Font.DIALOG, Font.BOLD, 36);
					JLabel lev = new JLabel("LEVEL "+p.getLevel());
					lev.setBounds(420, 130, 300, 30);
					lev.setFont(infoF);
					JLabel userName = new JLabel(initials.getText());
					userName.setBounds(430, 160, 200, 40);
					userName.setFont(infoF);
					
					JButton main = new JButton("MAIN MENU");
					main.setBounds(325, 575, 125, 30);
					main.setForeground(new Color(255, 255, 255));
					main.setBackground(new Color(216, 49, 71));
					JButton quit = new JButton("QUIT");
					quit.setBounds(525, 575, 125, 30);
					quit.setForeground(new Color(255, 255, 255));
					quit.setBackground(new Color(216, 49, 71));
					
					main.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent mainMenu)
						{
							scoreP.setVisible(false);
							mainMenu();
						}
					});
					quit.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent quitting)
						{
							System.exit(0);
						}
					});
					
					scoreP.add(score);
					scoreP.add(pts);
					scoreP.add(visual);
					scoreP.add(userName);
					scoreP.add(lev);
					scoreP.add(main);
					scoreP.add(quit);
					
					jf.add(scoreP);
				}
			}
		});
		
		for (int c = 0; c < 27; c++) // action listener
		{
			keys[c].addActionListener(new ActionListener() // letter clicked
			{
				public void actionPerformed(ActionEvent letter)
				{
					JButton b = (JButton)letter.getSource();
					String chosen = b.getText(); 
					
					if (chosen.equals("DEL"))
					{
						if (initials.getText().length() > 1)
							initials.setText(initials.getText().substring(0, initials.getText().length()-2));
						if (initials.getText().length() < 6)
							info.setText("Please input " + ((6-initials.getText().length())/2) + " more characters!");
					}
					else // other letters
					{
						if (initials.getText().length() < 5) // only 3 initials (+ spaces)
						{
							initials.setText(initials.getText() + " " + chosen);
							
							if (initials.getText().length() < 6)
								info.setText("Please input " + ((6-initials.getText().length())/2) + " more characters!");
							else
								info.setText("Press ENTER to see your score!");
						}
					}
				}
			});
		}
		
		for (int count = 0; count < 27; count++)
			keyboardP.add(keys[count]);
		
		infoP.add(info);
		infoP.add(enter);
		
		initialsBack.add(initials);		
		finishP.add(initialsBack);
		
		finishP.add(infoP);
		finishP.add(keyboardP);
		finishP.add(back);
		
		jf.add(finishP); 
		jf.repaint();
	}
}
