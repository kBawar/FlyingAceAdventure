/**
 * 
 * player, high score, playing status
 *
 */

public class Player
{
	private static int level;
	private static long curScore;
	private static String name;
	private static boolean playing;
	private static boolean lost;
	
	public Player()
	{
		curScore = 0;
		level = 1;
		name = "";
		playing = true;
		lost = false;
	}
	
	public void setName(String s)
	{
		name = s;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setScore(long score)
	{
		curScore += score; // adds onto current score
	}
	
	public long getScore()
	{
		return curScore;
	}
	
	public void setLevel(int lev)
	{
		level = lev;
	}
	
	public int getLevel()
	{
		return level;
	}
	
	public void setPlay(boolean b)
	{
		playing = b;
	}
	
	public boolean isPlaying()
	{
		return playing;
	}
	
	public boolean getLost()
	{
		return lost;
	}
	
	public void setLost(boolean b)
	{
		lost = b;
	}
}
